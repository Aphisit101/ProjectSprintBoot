package com.cp.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public interface UserService {

	User save(UserDto userDto);

	User findById(Long id);

	User update(Long id, UserDto userDto);

	User getUserByEmail(String email);

	Long findUserIdByEmail(String email);

	List<User> getAllUsers();
}
