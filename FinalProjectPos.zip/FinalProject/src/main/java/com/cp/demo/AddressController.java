package com.cp.demo;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/addresses")
public class AddressController {
    @Autowired
    private AddressService addressService;
    @Autowired
    private UserService userService;

    @GetMapping("/addressForm")
    public String showAddressForm(Model model) {
        model.addAttribute("address", new Address());
        List<User> users = userService.getAllUsers(); // Retrieve a list of all users
        model.addAttribute("users", users);
        return "addressForm";
    }

    @PostMapping("/saveAddress")
    public String saveAddress(Address address, @RequestParam("email") String email) {
        User user = userService.getUserByEmail(email);
        if (user != null) {
            addressService.saveAddress(address, user.getId());
        }
        return "redirect:/addresses/addressForm";
    }

}
