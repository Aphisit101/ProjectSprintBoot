package com.cp.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AddressServiceImpl implements AddressService {
    private final AddressRepository addressRepository;
    private final UserRepository userRepository;

    @Autowired
    public AddressServiceImpl(AddressRepository addressRepository, UserRepository userRepository) {
        this.addressRepository = addressRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    @Override
    public Address saveAddress(Address address, Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user != null) {
            address.setUser(user);
            return addressRepository.save(address);
        }
        return null; // Handle this case according to your application's logic
    }
}
