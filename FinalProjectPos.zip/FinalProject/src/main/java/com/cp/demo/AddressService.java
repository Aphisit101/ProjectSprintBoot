package com.cp.demo;

public interface AddressService {
    Address saveAddress(Address address, Long userId);
}
