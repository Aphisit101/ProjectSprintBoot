package com.cp.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class InventoryService {
	   
	  private ProductRepository productRepository;
	    // This means to get the bean called userRepository
	  
	   private CategoryRepository categoryRepository;
	   @Autowired
	  public void setCategoryRepository(CategoryRepository categoryRepository) {
		  this.categoryRepository=categoryRepository;
	  }
	   @Autowired
	   public void setProductReepository(ProductRepository productRepository) {
			  this.productRepository=productRepository;
	   }
	  @Autowired  //use constructor dependency injection instead of field dependency injection
	  public InventoryService( ProductRepository  productRepo, CategoryRepository catRepo) {
		  this.productRepository = productRepo;
		  this.categoryRepository = catRepo;
	  }
	  
	  public List<Category> getCategoryAll(){
		  return this.categoryRepository.findAll();
	  }
	  public  Category  getCategoryById(Integer id){
		  return this.categoryRepository.findById(id).get();
	  }
	  public void deletCategoryById(Integer id) {
		  Category category = this.categoryRepository.findById(  id)
			        .orElseThrow(() -> new IllegalArgumentException("Invalid category Id:" + id));
			      categoryRepository.delete(category);
	  }
	  
	  public void updateCategoryFromProduct(Integer id, Category cat) {
		  Product  product = this.productRepository.findById(id).get();
		
		  if(product != null) {
			  Category catPro = this.categoryRepository.findById(product.getCategory().getId()).get();
			  if(catPro==null)
				  cat.setId(id);
			  
			  this.categoryRepository.save(cat);
		  }
	  }
	  
	 public void saveCategory(Category c) {
		 this.categoryRepository.save(c);
	 }
	 public void saveProduct(Product p) {
		 this.productRepository.save(p);
	 }
	 public void deleteCategory(Category c) {
		 this.categoryRepository.delete(c);
	 }
	 public void deleteProduct(Product c) {
		 this.productRepository.delete(c);
	 }
	 
	 public List<Product> getProductAll(){
		  return this.productRepository.findAll();
	  }
	  public  Product getProductById(Integer id){
		  return this.productRepository.findById(id).get();
	  }
	  public void deletProductById(Integer id) {
		 var product = productRepository.findById(id).get();
			      productRepository.delete(product);
	  }
	  
}
