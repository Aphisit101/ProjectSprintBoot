package com.cp.demo;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.lang.String;

@Controller // This means that this class is a Controller
public class ProductController {

  @Autowired
  private ProductRepository productRepository;

  private InventoryService inventoryService;

  @Autowired
  public void setInventoryService(InventoryService s) {
    this.inventoryService = s;
  }

  @RequestMapping("/")
  public String root(Model model) {

    return "index";
  }

  @RequestMapping("/list_product")
  public String productForm(Model model) {

    List<Product> products = (List<Product>) inventoryService.getProductAll();
    model.addAttribute("products", products);
    return "productList";
  }

  @GetMapping("/delete_product/{id}")
  public String deleteUser(@PathVariable("id") Integer id, Model model) {
    // Product product = productRepository.findById((int) id)
    // .orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));
    // productRepository.delete(product);
    Product product = inventoryService.getProductById(id);
    inventoryService.deleteProduct(product);
    return "redirect:/list_product";
  }

  @PostMapping("/update_product/{id}")
  public String updateProduct(@PathVariable("id") Integer id, @Validated Product product,
      BindingResult result, Model model) {
    // System.out.println(id);
    // System.out.println(product.getId()+ product.getName());
    System.out.println(product);
    if (result.hasErrors()) {
      product.setId(id);
      // List<Category> categoryList = (List<Category>) categoryRepository.findAll();
      // model.addAttribute("categorytList", categoryList);
      return "update_product";
    }

    inventoryService.saveProduct(product);
    return "redirect:/list_product";
  }

  @GetMapping("/edit_product/{id}")
  public String showUpdateForm(@PathVariable("id") int id, Model model) {
    Product product = inventoryService.getProductById(id);
    // .orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));

    List<Category> categoryList = (List<Category>) inventoryService.getCategoryAll();
    System.out.println("in get update_product");
    model.addAttribute("categoryList", categoryList);
    model.addAttribute("product", product);
    System.out.println(categoryList);
    return "update_product";
  }

  @PostMapping("/new_product")
  public String addUser(@Validated Product product, BindingResult result, Model model) {
    if (result.hasErrors()) {
      List<Category> categoryList = (List<Category>) inventoryService.getCategoryAll();
      model.addAttribute("categorytList", categoryList);
      return "new_product";
    }

    inventoryService.saveProduct(product);
    return "redirect:/list_product";
  }

  @GetMapping("/new_product")
  public String showForm(Model model) {
    Product product = new Product();
    model.addAttribute("product", product);

    List<Category> categoryList = (List<Category>) inventoryService.getCategoryAll();
    model.addAttribute("categoryList", categoryList);
    return "new_product";
  }

  @RequestMapping("/product_list_json")
  @ResponseBody
  public List<Product> getCatoryList() {
    List<Product> products = inventoryService.getProductAll();
    return products;
  }

  @GetMapping("/dashboard")
  public String dashboard(Model model) {
    List<Product> products = productRepository.findAll();
    double totalRevenue = products.stream().mapToDouble(Product::getPrice).sum();
    int totalQuantity = products.stream().mapToInt(Product::getQuantity).sum();

    // Create arrays to store product names and quantities
    List<String> productNames = new ArrayList<>();
    List<Integer> productQuantities = new ArrayList<>();

    // Populate the arrays with data from your products
    for (Product product : products) {
      productNames.add(product.getName());
      productQuantities.add(product.getQuantity());
    }

    // Add the arrays to the model
    model.addAttribute("products", products);
    model.addAttribute("totalRevenue", totalRevenue);
    model.addAttribute("totalQuantity", totalQuantity);
    model.addAttribute("productNames", productNames);
    model.addAttribute("productQuantities", productQuantities);

    return "dashboard";
  }

}