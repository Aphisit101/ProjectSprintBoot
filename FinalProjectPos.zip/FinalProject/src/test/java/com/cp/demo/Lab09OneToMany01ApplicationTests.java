package com.cp.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab09OneToMany01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
